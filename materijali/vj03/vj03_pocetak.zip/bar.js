async function crtajBarChart() {
  // ovdje ide kôd

}
crtajBarChart()