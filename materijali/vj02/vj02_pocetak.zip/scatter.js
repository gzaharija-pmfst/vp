async function crtajScatter() {
  // ovdje pisemo kôd vježbe
  
}
crtajScatter()